-- AlterTable
ALTER TABLE `master` MODIFY `name` TEXT NOT NULL;
