-- AlterTable
ALTER TABLE `periode` MODIFY `status` BOOLEAN NOT NULL DEFAULT true;
