-- AlterTable
ALTER TABLE `indikator` MODIFY `name` TEXT NOT NULL;
