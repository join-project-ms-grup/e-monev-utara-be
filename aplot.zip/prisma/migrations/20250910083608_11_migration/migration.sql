-- AlterTable
ALTER TABLE `users` ADD COLUMN `status` BOOLEAN NOT NULL DEFAULT true;
