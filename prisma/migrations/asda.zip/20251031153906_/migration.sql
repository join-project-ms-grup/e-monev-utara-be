-- AlterTable
ALTER TABLE `skpd` MODIFY `shortname` VARCHAR(191) NULL;
